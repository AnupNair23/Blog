var express=require('express');  
 var mongodb=require('mongodb').MongoClient; 

var writingRouter=express.Router();  
var w_router=function(navMenu){  
    writingRouter.route("/")  
        .get(function(req,res){  
            res.render('writing', {  
                title:'Write Blog',  
                menu:navMenu,
                message:''  
            });  
        })
            .post(function(req,res){  
            var url='mongodb://localhost:27017/NodeDemoWebApp';  
            mongodb.connect(url,function(err,db){  
                var collection=db.collection('articles');  
                collection.insertOne(req.body,function(err,result){  
                    res.render('writing', {  
                        title:'Write Blog',  
                        menu:navMenu,  
                        message:'Successfully Blogged'  
                    });  
                });  
            });  
        });  


        return writingRouter;  
}  
      
module.exports=w_router;  